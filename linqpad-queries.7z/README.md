# linqpad-queries
my personal collection of linqpad files
